---
layout: layout-digitalmidstream
class: digital-midstream
permalink: /digital-midstream
title: "Digital Midstream™"
subtitle: Pipelines no longer necessary. 
description: >
  Digital Midstream™ is what we call our no cost, location-agnostic solution to excess natural gas problems. With Digital Midstream™, you no longer need to rely on traditional midstream. 10NetZero brings midstream to you, digitally, wherever you are.
# video:
#   label: Watch the video
#   link: "#"
#   icon: "/assets/img/PlayCircle.svg"
# audio:
#   link: "#"
#   icon: "/assets/img/audio.svg"
hero_background: "/assets/img/dm_hero.png"

## Section #1
section_1:
  show: true
  title: >
    ## Where we're going, we don't need pipelines.
  link: "#"
  image: "/assets/img/section_1.png"
  webp-image: '/assets/img/section_1.webp'

## Section #2
section_2:
  show: false
  title: '<strong>Wasting</strong> Gas is No Longer Necessary'
  image: '/assets/img/global-flaring.jpg'
  webp-image: '/assets/img/global-flaring.webp'
  # title: >
  #   Natural gas flaring is one of the biggest sources of waste and emissions
  # text: Now, it’s no longer necessary
  # bg: "/assets/img/bg_s2.webp"
  # cards:
  # - value: $3.57 Billion
  #   speed: 357 Bcf/year
  #   label: Flared & Vented gas
  # - value: $1.63 Billion
  #   speed: 163 Bcf/year
  #   label: Permitted operating flares
  # - value: $1.4+ Billion
  #   speed: 145 Bcf/year
  #   label: Medium size permian

## New Section #2
section_2_new:
  show: true
  title: >
    ## Unmet Demand
  text: |
    Traditional pipeline is old, slow, inflexible, and expensive. And the gap between traditional pipeline and producers is only <span class="text-orange">widening</span>.

    **Today’s Operators Need a New Solution. One Built For the 21st Century.**

## Section #3
section_3:
  show: false
  title: >
    ## No **Energy** Wasted
  text: Fields are getting more gaseous. The status quo can't keep up. We are here to give operators real, scalable, plug-n-play solutions that add value instantly.
  widgets:
  - title: >
      ### Expected Oil Production, USA
    image: "/assets/img/projected-oil-production.png"
    webp-image: "/assets/img/projected-oil-production.webp"
  - title: >
      ### Expected Natural Gas Production, USA
    image: "/assets/img/projected-gas-production.png"
    webp-image: "/assets/img/projected-gas-production.webp"

## New Section #3
section_3_new:
  show: true
  title: >
    ## Digitizing Supply
  text: |
    A flexible, reliable, scalable, mobile service designed to buy and utilize your gas at the source...wherever that may be.

    We call it Digital Midstream™

    **Giving today’s operators more choice, <br /> less risk, and a better bottomline.**

## Section #4
section_4:
  show: false
  title: >
    ## **Reducing** CO2e's
  text: Natural gas has already provided immense savings in GHG emissions, and it will continue to do so as net zero initiatives will take decades. We make natural gas even more environmentally friendly by utilizing otherwise wasted natural gas, converting it to electricity, and reducing flare intensity and methane emissions.
  widgets:
  # - title: >
  #     ### Emissions avoidance Per. 1.7 MW System (Tons CO2 e/ye)
  #   image: "/assets/img/w4_11.png"
  # - title: >
  #     ### Emissions avoidance Per. $1.000 investment (Tons CO2 e/ye)
  #   image: "/assets/img/w4_21.png"
  - name: Reduced Methane
    amount: 99
  - name: Reduced CO2e
    amount: 63
  - name: Reduced VOCs
    amount: 93

## New Section #4
section_4_new:
  show: true
  title: >
    ## **Benefits**
  #text: Our plug and play solution to excess natural gas allows us to take gas from producers with 99%+ uptime. It’s also scalable from some of the smallest wells to entire fields! And not to worry - our equipment takes almost no space, leaving your operations unhindered. And if we ever need to move, there are no issues as our operation is almost entirely mobile.
  widgets:
    - name: 99%+
      text: Uptime
    - name: Scalable
      text: Fits any size well
    - name: Mobile
      text: Easily Moved
    - name: Small Footprint
      text: Minimal Intrusion

partners:
 - "/assets/img/p_logo_1.png"
 - "/assets/img/p_logo_2.png"
 - "/assets/img/p_logo_3.png"
 - "/assets/img/p_logo_4.png"
 - "/assets/img/p_logo_5.png"
 - "/assets/img/p_logo_6.png"
---
