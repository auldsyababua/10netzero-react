---
type: post
post_title: "Bitcoin Mining: The Definitive Guide (2022)"
author: Colin Aulds
updated: 2022-04-12
blog_image: /assets/img/ten_net_zero_hero.jpg
author_image: '/assets/img/colin-aulds-250.jpg'
layout: post
categories:
  - Mining
output:
  html_document:
  toc:
    min_level: 2 # default: 1
    max_level: 2 # default: 6
toc:
  min_level: 2 # default: 1
  max_level: 2 # default: 6
  
url: /mining-guide/
---

Today I’m going to teach you everything you need to know about Bitcoin Mining:
+ What it is and why we do it
+ What hardware and software you’ll need
+ The kinds of facilities required to mine profitably
+ How to increase your chances of getting paid
+ What the future of mining looks like
+ Lots More
So if you want to understand Bitcoin mining on a deep level, you’ll want follow this updated guide.

Let’s get started.

## Chapter 1: Bitcoin Mining 101


If you want to know how to start mining Bitcoins yourself, you must first understand what mining is and why we do it. 

If you are like most people, you may be wondering:

“How does burning electricity and doing math mine Bitcoins? What is the point?”

Answering these questions is what this chapter is all about, so let’s dive in. 

### Mining, Put Simply...

Mining is really pretty simple. 

Bitcoin does not have a central government. There is no Bitcoin company. 

Because of this, there is no Bitcoin boss that says “print more Bitcoins now!”

Instead, a set number of Bitcoins are printed on a predetermined schedule by “unstoppable code”. 

Approximately every 10 minutes, 6.5 Bitcoins are minted or “mined”. 

You may be wondering, “who gets these newly minted Bitcoins?”

Well, the miners do. These new Bitcoins are a sort of payment for a service performed by the miners to the network.
### The Role of the Bitcoin Miner

What is the point of the miner? Why can’t the Bitcoin network work without them?

The TL;DR is that miners secure the network.

But what does that even mean? Why does the network need protecting? Who would attack it and how would they do so?

Let’s explore those questions a bit further.

Again, remember that there is no Bitcoin government. Bitcoin needs a way to determine who’s Bitcoins are who’s without any one person being in charge. 

Traditionally, a central authority like a government or a bank keeps track of your money for you. If someone steals your money, the government prosecutes them or the bank gives you your money back. 

When you send $10 to your friend, the bank deducts $10 from your account and adds $10 to your friend’s account. 

### The Problem With Centralized Money

But this creates a problem. What if the bank just decides it’s going to take the money for itself? There isn’t much you could do about it. When the bank holds your money, all you really have is an IOU from the bank.

And sometimes it’s not the bank you need to worry about. Sometimes the government decides to take your money by printing more money. This dilutes the value of your dollars, even though you have the same amount in your bank account. 

You may already be aware that Bitcoin allows you to be your own bank by allowing you to securely custody the coins yourself. It also protects you from money printing because there can only ever be 21 million Bitcoin ever.

Bitcoin achieves these goals through decentralization - if no one person controls the Bitcoin Network, then no one can print them or easily steal them. 

And mining (along with the ability to verify all the transactions yourself) is the solution that keeps the network safe and decentralized. 

### Protection Through Decentralization

That begs the question: how does mining keep the network decentralized?

Answering this is really the beginning of understanding how mining works. 

I’m going to simplify this to some degree, but I want you to imagine a lottery. 

There are many tickets, but only one of them wins.

In Bitcoin, this lottery happens every 10 minutes and the jackpot is 6.25 Bitcoins plus some extra Bitcoin thrown in for the fees paid by transactors. 

To buy a lottery ticket in this lottery, you don’t pay money. Instead, you use your computer to solve math problems. 

The faster your computer is, the more tickets you get. 

The more tickets you get, the more likely you are to win the lottery.

Many people run multiple computers (sometimes thousands) to try and maximize the number of tickets they get.

Eventually someone wins.

### Benefits of Winning

Whoever wins the lottery not only gets the prize but they also get to construct the block. This just means that they decide which of the transactions to include in that block and which order they go in. 

Usually, the winner chooses the transactions that paid the most in fees since this increases the miner’s total jackpot.

Now, you may be asking “How does this decentralize the network?”

Well, as you can see, mining is very resource intensive. It requires a lot of real-world energy and, these days, very expensive specialized computers called ASICs (Application Specific Integrated Circuits) that become obsolete and inefficient very quickly. 

To truly control the network, you really need to control greater than half of all the mining power (or ‘lottery tickets’ in our example), and you’d need to do this several lotteries in a row.

Only as long as you can keep winning the lottery do you control the network. 

### The Size of Bitcoin Mining

Today, Bitcoin burns an incredible amount of energy - about the same amount of energy used by the entire country of Switzerland (77 TWh). 

Even if you had access to that much energy, you would also need a stupendous number of ASICs. 

Even if you achieved this, you’d probably spend more time and money than you’d make in profit, especially since initiating this attack on Bitcoin would greatly reduce the value of any Bitcoins you were able to steal in the first place. 

And the history of hashing power (or the number of lottery participants) on the network really only grows every day. 

So it becomes harder and harder to control greater than 50% of the mining power.

And that, put very simply, is what miners do and why they do it. They are selfishly spending money in order to get a return on their time and investment. 

Because so many are competing to do the same, it makes it very hard (if not impossible in the case of Bitcoin) for any one party to control the majority. 

As long as that is true, Bitcoin remains decentralized and safe to use. 

There are some nuances to this that we will discuss in the coming chapters, but thinking of mining in this way is very useful if you want to understand Bitcoin mining. 

## Chapter 2: Everything You Need to Start Mining 

Now that we know what happens when we mine Bitcoins, it’s time to go a little deeper to understand what sorts of tools miners depend on daily to earn Bitcoins. 

Contrary to popular belief, mining Bitcoins is much more involved than just hooking up your computer to some software and letting the Bitcoins fill your wallet.

There are three parts to any mining operation: infrastructure, hardware, and software.

Read on to find out about each. 
### The Hardware That Secures Bitcoin

The most obvious part of Bitcoin mining is the hardware. That is probably because it’s something you can see and hold, and most people are familiar with a computer. 

But the kinds of computers used to mine Bitcoin are very different from the one you play video games or watch youtube on. 

As mentioned in Chapter One, today miners use an ASIC specifically designed to mine a particular hashing algorithm. In the case of Bitcoin, they mine on the SHA256 hashing algorithm. Some coins use other hashing algorithms, but that is not really important here. 

All you need to understand is that an ASIC designed to mine Bitcoins is far more efficient (as in, exponentially more efficient) than a standard computer would be. 

But Bitcoin mining hardware wasn’t always so specialized. 

#### What We Used to Mine On

In the beginning (and I’m talking the VERY beginning), Bitcoins were mined on CPUs. In fact, much weaker ones than the one your computer uses right now. 

This was back when there were only a handful of people trading Bitcoins and it was all very experimental. 

Back then, there was so little hashing power on the network that anyone with almost any hardware could win a block. 

Then came the GPUs (graphical processing units). These chips have traditionally been used for high performance gaming computers. 

However, they could be repurposed to mine Bitcoins. GPUs changed the mining game considerably. With a GPU, a miner could greatly increase his number of hashes per second. 

As more and more miners used GPUs, the difficulty increased, which required more and more hashes to win a block. 

And that brings us to today.  

#### Purpose-Built Bitcoin Mining Hardware

At least for Bitcoin, there is no way to run a GPU or CPU miner profitably. And that is for a very simple reason.

ASICs (or Application-Specific Integrated Circuits)

ASICs are chips that do one thing and one thing only. In the case of a Bitcoin mining ASIC, the application is mining coins that use the SHA256 hashing algorithm for its Proof of Work consensus algorithm. 

That may sound like a lot of Latin, but it basically means that for the first time in Bitcoin mining history, hardware purpose-built for the task of mining Bitcoins had been invented.

These ASICs can’t browse the internet. They can’t play video games. They can’t calculate your taxes. They wouldn’t just suck at these tasks - they are incapable of doing them at all. 

So why would you use them to mine Bitcoins? 

Because what they lack in flexibility, they make up for in mining efficiency. 

#### GPUs vs ASICs: Which is Better?

To give you a sense of the difference, compare the top graphics card and Bitcoin mining ASIC from 2017. The Nvidia 1080Ti was the envy of every gamer that year. And for miners, it did not get better than an Antminer S9 from Bitmain. 

If you were to mine Bitcoins using the 1080Ti, you’d get 980 megahashes per second, for a power draw of 150 watts. That’s a total of 6.5 megahashes per watt.

For the Antminer S9, you’d get 13,500,000 megahashes per second for a power draw of 1,323 watts. That’s a total of 10,204 megahashes per watt.

As you can see, the Antminer absolutely spanks the 1080Ti. But what about price?

#### Does Price Change the Equation?

How much would you have paid for each of these pieces of hardware in 2017?

That is an excellent question, because what you pay for hardware also affects how profitable you are.

So let’s look at that next.

For a brand new Antminer S9 in 2017, you would have paid $2,100 (if you could even get one). 

For a brand new Nvidia 1080Ti in 2017, you would have paid $700.

So the Antminer S9 would have cost you triple what a 1080Ti would have cost you.

So our math is easy: if we buy 3 1080Ti’s would we be able to mine more Bitcoin than 1 Antminer S9?

Hopefully it’s obvious by now that we wouldn’t even be remotely close. In terms of hashes per watt, the S9 is 1,569 times more efficient. 

And today, an Antminer S9 would not cost you nearly that much. An S9 can be had today for about $350. 

#### Quickly Depreciating Assets

You may be wondering why an S9 would be worth so little today.

Well, it’s because newer, more efficient ASICs have since hit the market.

The Antminer S19 Pro, which boasts 110,000,000 megahashes per second, has a power draw of 3,250 watts. That means you get a total of 33,846 megahashes per watt - about triple the efficiency of the S9. It costs about $1,995. 

As new ASICs hit the market and mining farms add them to their array of hardware, total hashing power on the network increases. This pushes up the mining difficulty on the network, which makes each individual hash less and less likely to result in winning a block. 

So while the hashes per second per watt stays the same for the S9, the value of that power goes down over time as well. To go back to the lottery metaphor, each ticket may cost a dollar, but as more people play, the less likely any single ticket is to pay off. 
### The Software Miners Need

Of course, hardware is really only one piece of the puzzle. Like any piece of computing hardware, an ASIC is really just a hunk of worthless metal and silicon without the software to make it tick....or hash ;-).

There are a number of pieces of software miners use to mine Bitcoins everyday.

#### Mining Firmware

Mining firmware is basically the brain of your hardware. There are many different mining firmware out there to use, and they all offer different features and settings to tune your hardware the way that you want. 

You could write a whole book on this topic alone, but doing so is not the goal here. 

All you need to know is that the firmware you choose for your hardware will affect the efficiency of your mining operation. It also generates data about the health of your hardware and its performance to help improve your operation.  

#### Mining Pool Software

Going one level up is mining pool software. We will cover mining pools in much greater detail in Chapter 4. 

For now, you can think of mining pools similar to a lottery pool at work - everyone in the pool is “pooling” their hashing power in order to win a block as a group.

However, in order to coordinate all of this without knowing any of the other miners, you need some software to hook up your miners to the pool.

Again, a whole book could be written on the topic of mining pool software alone. But some of the features of mining pool software include: 

+  Reducing latency issues with data transfers between you and the mining pool
+  Preventing man in the middle attacks between you and the pool (hashrate hijacking)
+  Constructing your own block templates (better hash or stratum V2)

#### Accounting Software

An oft overlooked piece of software is crypto accounting software.

As a miner, you will be earning Bitcoin daily, which means you are effectively entering the market at many different prices.

It can become extremely complicated to maintain your books in this circumstance because of how the IRS and most other countries tax Bitcoin. 

Having a quality accounting software to keep track of all these taxable events will save you a lot of time and money and ultimately increase your profits. 

You can check out out our [tax page](/cryptocurrency-taxes/) to learn more about the best options.

### Bitcoin Mining Infrastructure

Before you go out and buy a bunch of hardware and software, you need to look at your energy situation. 

Infrastructure is a big factor in mining Bitcoin profitably. In fact, it is without a doubt the most important variable.

Here’s the deal: with Bitcoin mining, you are competing in a market. Whoever can get hashes at the cheapest price wins the most Bitcoins. 

The hardware and the software costs the same for everyone, more or less. Sure, you may be able to buy some ASICs in bulk and save a little money, but that won’t really help you much if you can’t get one thing really cheaply - electricity.

Electricity is almost the only variable cost to mining. That means that if everyone is getting hardware and software for the same price, electricity costs are the differentiator. Miners who can get cheap energy continue to compete. Miners who don’t, shut down. It’s that simple.

We’ll discuss this a lot more in Chapter 6 on environmental impacts, but for now, all you need to know is that if you can’t get cheap electricity, you will be priced out of the market.

#### How Expensive is Too Expensive?

So you may be wondering what price you’d need to really compete today. 

In 2020, $0.05 per Kilowatt-hour is about as high as you’d want to pay. More than that, and it becomes much harder to compete. 

Take a look at wherever the most mining takes place. 

Now look up the average energy prices of the places that have the most mining. 

What you will find is that energy tends to be incredibly cheap.

#### Exceptions to the rule

If you look at that map really closely, you may find a few locations where energy doesn’t actually look very cheap. 

In these cases, there is almost always a special reason the mining is happening there. 

Perhaps the government is subsidizing the cost of the energy in order to attract mining farms. 

In other cases, mining farms have set up near natural gas fields and run off generators. 

The energy companies traditionally ‘flared’ or set this excess ‘waste’ gas on fire. But miners have come in and offered to use it. 

This saves the energy company money so they sell it to the miners for almost nothing. This is a win/win for all parties. 

#### Price Isn’t Everything

Another consideration for professional miners is scalability. That is, they want to take a small operation and expand it while maintaining the same profitability.

In many places with cheap electricity, this isn’t possible - either for logistical reasons or political ones. 

#### Logistical Barriers 

Let’s look at an example of a logistical barrier.

In countries with naturally cheap electricity, like Iceland, some miners run a few ASICs at home. However, they will never be able to expand their mining operation because the infrastructure isn’t there to do so. A home power socket can only pull so much energy from the grid.

If they want to expand, they would need to find an industrial location to mine that has access to greater inflows of power. 

#### Political Barriers

As for a political barrier, we can look at countries like Iran or Venezuela. 

In these countries, power is completely subsidized by the government. All that means is the average citizen does not pay for electricity. It is ‘free’, or rather included in their taxes. 

Because of this (and because of the poor quality of their local currency) many have resorted to mining Bitcoins in their home. This type of mining doesn’t account for much of the total hashing power because in many cases, these miners are not using ASICs. They are using GPUs in their computers.

You’re probably wondering how they mine using GPUs since we already learned how inefficient they are. 

Well, if you aren’t paying for electricity, it doesn’t really matter. Any Bitcoin the GPU mines is all profit since the graphics card is already owned and the electricity cost is 0.

#### Time to Scale it Up?

So why not buy some ASICs and scale up your operation?

This is where it gets political. In most of these countries, it is illegal to mine Bitcoins precisely because the energy is free. 

When the government decided to make electricity free for its citizens, it never anticipated being able to print money in exchange for electricity. And, in most cases, these governments view Bitcoin as subversive to its own currency.

However, if you are just mining Bitcoin using a GPU in your house, it’s not going to raise any red flags - it just looks like you are running your computer a lot. 

But once you start adding a bunch of ASICs, with much higher power consumption, that gets attention. The authorities are going to wonder why you are using so much electricity. Eventually they may even come and arrest you and take your hardware. 

This makes it virtually impossible to mine at scale, but small operations likely will not get noticed. And even a small GPU mining operation can mean eating a meal or going hungry in these countries.  

#### Chill Out

Let’s not forget another crucial detail about mining infrastructure. 

The truth about Bitcoin mining is: ASICs need to run 24/7 in order to get the maximum value out of them. ASICs quickly become obsolete to newer, more efficient ASICs that hit the market. The moment you buy an ASIC, its days are numbered in terms of profitability.

But an ASIC’s days can be numbered in another way if you don’t care for them properly. 

That’s because ASICs run hot...REALLY HOT. 

Their normal operating temperature is around 75-80 degrees celsius (167-176 degrees fahrenheit). 

If they overheat, they could die or worse, catch on fire and risk the rest of your mining hardware.
(insert headline here)

If that happens: bye-bye profits, hello losses. 

Your mining software should alert you to overheating and turn off any miners that are in the danger zone. But still, every day a miner is not running is a day it makes no money and a day closer to being obsolete. 

That is why proper temperature management is key, especially in large scale mining farms. 
Even if you manage to get cheap electricity and you find a great location with access to lots of power, mismanaging the heat could end up being the biggest financial mistake of your life. 

I am not a heat management expert, so I can’t detail how to do so here. All you need to know is that you either need an engineer on staff to handle this or you need the knowledge to do it yourself. 

### Summing it Up

So getting cheap energy is only half the battle if you want to make mining your career. 

You’ll also need to find a location that can serve you lots of energy to mine at a larger scale. 

And you need to make sure you or someone on your staff knows how to manage the temperature regulation of your hardware so you have maximum uptime. 

Achieving this requires the following:

+  Checking the local laws regarding Bitcoin mining
+  Making a deal with a local power company
+  Finding an industrial location that is set up to consume large amounts of power
+  Hiring a farm manager with experience in heat management 


## Chapter 3: How Bitcoin’s Price Affects Miners


You now understand what Bitcoin mining is and all of the tools and facilities needed to do it profitably. 

But there is one piece of the equation I left out:

The price of Bitcoin.

But what does the price of Bitcoin have to do with mining?

More than you think - along with the price of energy, the price of Bitcoin is make or break for many mining operations.

Let’s jump into it! 

### One More Obstacle

I know - I keep laying new obstacles to mining onto you. 

But I promise, this is the last one, and it’s pretty easy to understand.

Imagine you have set up your mining farm. You have a great location with lots of power and your electricity is coming to you at a cheap price. 

Things seem good. 

After paying for all your ASICs, paying rent on the facility you are using, and your power bill, your expenses are around $150,000 a month. Thankfully, your mining results in $190,000 worth of Bitcoin. 

Every month, you sell at least enough to cover your expenses. 

Then...the price crashes 30%, as it has done many many times before. 

What does that mean for you?

Well, unfortunately, you already spent all that money on your ASICs. And your landlord and power company don’t really care what the Bitcoin price is - they expect payment regardless.

And worst of all, you aren’t mining any more Bitcoin than you usually are.

What used to be worth $190,000 a month is now worth $133,000 a month, which puts you short $17,000 each and every month you operate.

All you can do is shut down and hope the price comes back up soon enough to get things going again and make your payments.

This is the life of the Bitcoin miner and it is why mining is so competitive. You can lock in every variable there is except the price of Bitcoin. 

### Price or Hashrate: Cause and Effect

This is just one possible version of this story. 

Sometimes the price goes the other way. You mine the same amount of Bitcoin but the price goes up and you are even more profitable. 

Again, the power bill is the power bill, regardless of what the price of Bitcoin is. 

That said, there are some knock on effects to the price of Bitcoin and the total hash rate globally.

That’s because the total network hashrate tends to follow the price. 

Before we can really understand that, we need to know how difficulty and total network hashrate work. 

### The ‘Difficulty’ With Mining

You see, in Bitcoin mining, there is something called ‘difficulty’ and a ‘difficulty adjustment’. Difficulty is just a measurement of how many hashes are expected to find a block. Difficulty adjustments are changes in this difficulty level up or down in order to hit a certain target called a ‘bdiff’.

These are what keep blocks coming in on a fairly consistent 10 minute basis. It’s not perfect, but on average, it is very reliable.  

Here is how it works (put simply):

The protocol has certain rules: 

+  If the last 2,016 blocks took more than two weeks, the difficulty goes down.
+  If the last 2,016 blocks took less than two weeks, the difficulty goes up.
+  How much the difficulty goes up or down depends on how much less or how much more time it took to mine 2,016 blocks relative to two weeks.

(insert graphic here)
### An Example of Difficulty Adjustment

We want 2,016 blocks to take two weeks. That is 10 minutes per block on average.

2,016 blocks times 10 minutes equals 20,160 minutes to find 2,016 blocks. 

At the end of the measurement period (2,016 blocks), we want the expected number of minutes (20,160) to equal the actual number of minutes. If it does, we don’t need to adjust anything. If it doesn’t, we do need to adjust. 

We can do that with a division problem. We want to divide the expected by the actual and see if it equals 1.   

20,160 / 20,160 = 1 

But let’s say that blocks were found, on average, every nine minutes. 

That means it only took 18,144 minutes to find 2,016 blocks. 

20,160 / 18,144 = 1.11

Uh-oh...that was too fast.

The protocol will see this and increase difficulty by 11% for the next 2016 blocks. It will do this by multiplying the current difficulty by 1.11 in order to try and bring difficulty back to the equilibrium of 1. 

### Back to Price and How It Affects Miners

So now you understand difficulty adjustments, but so what?

Why does this matter to you if you want to mine?

Here is the short of it: If a bunch of miners are suddenly made unprofitable by a major price swing, the difficulty will very likely adjust downward1 once that series of 2016 blocks is finished. 

Total hashrate is constantly changing. And the protocol is always adjusting to keep up with the changes.

The reason I bring up difficulty is, first, you need to understand how these difficulty adjustments may affect your bottom line. If difficulty goes up, that means it’s going to be harder for you to compete since more hashing is required per Bitcoin. 

But the reverse is also true - as difficulty adjusts down, you will become more profitable, but only if you survived the price swing downward.  

But there is another reason I bring up difficulty, and that is you understand that price does not follow hashrate, as many seem to misunderstand.

Instead, hashrate follows price. 

So the next time you see someone talking about how the increased hashrate will result in a Bitcoin boom in price, you will know the prediction is flawed. You will also know that times are going to get harder for you - not easier.

### Summing It Up

Here is the discouraging part for new miners: total hashrate really doesn’t ever go down. 

While there are tiny blips where it goes down temporarily, that really all it is - temporary. The main story of Bitcoin mining is one of increasing hash power on the network. 

Drops are very local, and really only visible on a day to day timeline. From a zoomed out view, the trend is quite clearly going up.     

There is some good news here though: it means that if you do have to shut down, you can usually wait for the price to increase and come back. 

Or, if you do shut down for good, there is always a buyer willing to buy your equipment and add it to their profitable mining operation.

## Chapter 4: Win more Blocks with a Mining Pools

You may remember that in chapter 2, we mentioned a thing called a ‘mining pool’. 

Well, this chapter is dedicated to understanding mining pools and why you should use one.

(Hint: it has to do with increasing your chances of earning Bitcoin)

In fact, without mining pools, very few miners could make a consistent profit, so you will certainly want to pay attention in this chapter. 

### Mining Pools are Like Lottery Pools

To understand mining pools, it will be helpful to go back to our lottery example.

Many offices participate in ‘lottery pools’ where each person buy a lottery ticket and all the participants agree that, if they win, they will split the winnings evenly amongst the group. 

Let’s say the jackpot is $1,000,000. You and four coworkers each buy a ticket. If you play alone, let’s say you have a 1 in one million chance of winning. 

But if you join the lottery pool, you multiply your chance of winning something by 5 (since you now share 5 potential winning tickets). If you win, you only make $200,000, but you think it’s worth the trade off. 

Mining pools work very similarly. You contribute your hashing power (the equivalent of your lottery ticket) to a pool of other miners who do the same. All of you decide that whatever blocks are won by any miner in the pool are dispersed proportional to hashing power contributed.

So for instance, if your hardware is responsible for 25% of all hashes that the pool contributes to the network, and your pool wins a block, you’ll earn 25% of the Bitcoins earned from that block. 

That is, of course, minus the fees.

You see, when you join a pool, someone has to run that pool. When the pool wins a block, the pool operator has to build that block and choose which transactions to include in it. And, the pool operator has to coordinate all of its miners so that they working most efficiently to a common goal.

All of this takes time and money, and they expect to get paid in exchange for the service.

Of course, in most cases, the price is well worth it. 

Without pools, even large mining farms might go months or years winning a block and earning Bitcoin, just as you might not ever win the lottery even if you buy tons of tickets. 

However, if you could join a pool of lottery tickets where 20% of the combinations were accounted for, you’d win part of a lottery reward, around 20% of the time.  

Below you can find some of the most prominent mining pools:

### Do Pools Own the Mining Power?

While we can see which mining pools are the largest, it’s important to understand that the hash power pointed towards a mining pool isn’t necessarily owned by the mining pool itself.

There are a few cases, like with BitFury and KnCMiner, where the company itself runs the mining operation but doesn’t run a mining pool.

Bitcoin miners can switch mining pools easily by routing their hash power to a different pool, so the market share of pools is constantly changing.

To make the list of top 10 miners, we looked at blocks found over the past 6 months using data from BlockTrail.com.

The size of mining pools is constantly changing. We will do our best to keep this posted up-to-date.


### Getting Paid By Your Pool


## Chapter 5: Obstacles in the Mining Industry

You’ve now got a pretty solid understanding of how to mine Bitcoins.

But you should be aware of some of the issues and challenges facing miners today.

Some of them are technological. Some are legal. Some are even ideological. 

How can something so mechanical and mathematical possibly have so many different kinds of challenges? 

That will be made clear by the end of this chapter. Let’s go.


### KYC and AML Laws

This is a new one. 

If you aren’t aware of KYC and AML laws, they are pretty simple. 

Government’s all over the world have various rules for financial firms called “Know Your Customer” and “Anti-Money Laundering” regulations. 

These rules are supposedly in place to prevent fraud, terrorism, or other criminal activity. However, in a great many cases, these rules are used as a form of domestic and international surveillance of law-abiding citizens.

Or sometimes...of citizens who are disobeying unfair or immoral laws put in place by tyrannical regimes. This is especially true of Bitcoin.

In 2020, almost every exchange worth trading on are subject to these laws and are more than willing to comply since they cannot do business otherwise. In many cases, though, they over comply in order to get on the good side of regulators. 

And now, for the first time, we are seeing mining pools begin to act the same way. 

Vancouver-based blockchain company DMG just announced that their new mining pool Blockseer will comply with canadian KYC and AML laws. 

This means that they will use chainalysis to determine transactions with presumed criminal origin and exclude them from blocks that they win. 

Thankfully, this will result in increased costs to running the pool as well as decreased rewards, since they will often need to exclude the transactions that pay the highest fees. 

Therefore, it costs more money to run the pool and it will make less. 

This is a very unappealing prospect for most miners out there and so it seems unlikely that many people would join this pool, but there is greater difficulty at hand.

In the case of DMG, they are voluntarily over-complying with these laws. There are no rules stating mining pools must adhere to KYC/AML laws.

However, what if the Canadian government decided that mining pools did need to comply?

Thankfully, most mining pools operate outside of Canada, but what if China and the US and many of the other main countries decided to enforce their KYC/AML laws on miners. 

That would be another story. 

As far as you are concerned, you need to be aware that, if you want to run a mining operation, you’ll probably want to join a pool that doesn’t participate in KYC/AML or headquarter in a country that is likely to impose these rules on pools.

### Mining Centralization

This is a threat as old as Bitcoin. 

The idea is simple. As we discussed in Chapter 1, if someone were able to control a majority of the hashing power on the network, they could effectively steal Bitcoins. This undermines the entire value proposition of Bitcoin as a secure store of value. So preventing this is important.

So let’s go back to mining pools. 

Remember that pools are made up of a bunch of individual miners who all contribute their hashing power into a pool to share the rewards.

What if no individual miner controlled half of the hashing power, but a pool did?

That could be very bad, and in the past, we’ve come incredibly close. 

Fortunately, there are many incentives for a pool not to use that power for evil, since doing so would put their entire future in jeopardy. This is what I call the ‘king of shit hill’ defense.   

You may be able to steal a few coins with a 51% attack. But in doing so, you may end up crashing the price of Bitcoin since you are undermining the entire network in the first place.

There are other defenses against this threat that are being developed right now. Those will be discussed in Chapter 7 below. 

There are other risks to mining centralization though. 

And these have nothing to do with pools. They have more to do with geography. 

If you imagine the mining farm operators in China, you can see what might happen. 

Currently, 65% of all Bitcoin mining happens in China. 

If the Chinese government wants to stifle Bitcoin, they could outlaw bitcoin mining overnight if they wanted to. Assuming most of the big miners would comply, that would be a massive hashrate drop overnight. 

And in fact, that is exactly what happened in 2021.

This brings us to the third hurdle

### Regime Uncertainty

Speaking of the Chinese government, it’s worth discussing the regime you live under right now.

If you are considering starting a mining operation, you first need to find out if mining is even legal. 

If it is, is it likely to stay that way? Is there lots of uncertainty regarding the political future of your country?

If so, you may want to think twice about sinking tons of money into a mining operation. 

Countries are always changing their laws around Bitcoin and mining, so make sure your country is fairly predictable on this topic.

### Block Subsidy Termination

This is a big one.

Essentially, the question is: what happens to Bitcoin mining once the block subsidy (the 6.25 Bitcoins that are rewarded to each block winner) runs out? 

In the early days, you could send Bitcoin and pay almost no fees. However, as Bitcoin has grown, block space is limited and so a fee market developed. 

This fee market is just an auction for block space. If you want to get your transaction into a block faster, you may need to pay higher fees. This is mostly true when the mempool is very large3.

Now fees are quite substantial, but they are nowhere near 6.15 Bitcoins. 

So the question really is, will fees be enough to make mining profitable when there is no longer a block subsidy? 

Many say yes. 

These people think others will just pay higher fees to make up for it. But we’ve already seen fees as high as $100 for some transactions and that was when the block subsidy was 12.5 Bitcoins. Will people really be willing to pay more?

Maybe.

The argument that says they will be points out that when there are no more Bitcoins being mined, the value of your Bitcoin increases since there is no new flow of Bitcoins. In fact, Bitcoins will tend to become more scarce as some of the existing supply are lost due to user error. 

However, many would say these facts are already priced in.

Some have suggested we fork Bitcoin and change the rule so there is always a block subsidy to ensure that miners will always continue mining. 

The truth is one knows what will happen and that uncertainty can be impactful to a mining operation who plans on mining for a long time. Thankfully, the block subsidy isn’t expected to end until around 2140.

However, the subsidy does cut in half every 4 years and we may live to see a day when it is so small it won’t make much difference.

## Chapter 6: Environmental Impacts

As a miner, you will often meet people who will tell you bitcoin mining is wasteful.

They will make bold claims about how much you, as a miner, are harming the planet and preventing others from using scarce energy.

The truth is, these people haven’t spent much time considering the evidence. 

Bitcoin mining, per kilowatt/hour, is one of the most environmentally friendly operations on Earth. 

Read on to find out how. 

### Bitcoin and Energy
 
Bitcoin needs a lot of energy to keep the network secure and safe.

Many wonder if the energy used is too much? After all, isn't an increase
in energy usage the same as an increase in greenhouse gas emissions?

While it can be convincing to read into the worst of the headlines,
there is usally more to the story.

A small sampling of the alarming headines we see everyday about Bitcoin
energy usage

In this comprehensive overview, we will explore all of the nuance of
Bitcoin energy consumption, what its used for, and what we get in
return.

The answers may surprise you!

### What Does Bitcoin Use Energy For?

The technical details of Bitcoin's energy use are beyond the scope of
this post. But a simple summary is worth going over.

In short, Bitcoin uses energy to "mine" Bitcoins. This
mining process consists of solving incredibly complicated mathematical
problems. The math problems are solved via millions of computers around
the world. All of them attempt to solve these problems every 10 minutes.

Millions of computers across the world are racing to solve a problem.

Once the problem is solved, a new set of fresh Bitcoins are minted.
These computer "miners" are in competition with one another for these
new Bitcoins. The miner (or pool of miners) who solves
the problem first wins that round (or "block") of Bitcoins

All of this processing power (known as "hashing")
requires an enormous amount of energy. So much so that many mining
operations require dedicated contracts with energy suppliers and
specially constructed facilities in order to remain profitable.

Why is all of this necessary? Because all of this power consumption
makes it incredibly difficult (and expensive) to attack Bitcoin by
trying to change who owns how many Bitcoins. 

This is because you are tying the ability to change a digital record to something finite and
expensive in the physical world (energy).

If that still sounds confusing for you, you can read more about this
mining process in much greater technical detail on our mining
article.

Suffice it to say that mining *does* use a lot of energy and many wonder
if it is bad for the environment.

### How much energy does Bitcoin use today?

As of this writing on July 6th, 2020, Bitcoin uses about 60 Terra-watt
hours annually, or 10^12 watt hours.


That is roughly equivalent to energy consumption of
Switzerland.

### Does Bitcoin's Energy Use Prevent Others from Using the Energy?

One of the more common assumptions made about Bitcoin's energy
consumption is that because so much energy is used, it must prevent
others from using it.

For one thing, even if this were always true (it isn't), it rests on the
assumption that Bitcoin's use of the energy is somehow less important
than all the other uses. We'll discuss this further below.

The truth is, in many cases, Bitcoin is using energy that would
otherwise be wasted. This brings us to Bitcoin's energy sources.

### Sources of Bitcoin's Energy Use

A very large portion (if not the majority) of Bitcoin's energy comes
from China, and most notably in "green" powered areas like Sichuan and
Xinjiang where renewable sources like hydroelectric, solar, and
geothermal are common.

Map showing percentage of total Bitcoin mining in each province

In many cases, the energy produced by these wind farms and dams is
higher than the local grid can take. This means that they are producing
energy that would otherwise not be used by anyone since the local grid,
which takes energy and distributes it accross distances, cannot hold it.

Take Sichuan, for example:

Total hydropower reached more than 75 GW in 2017, greater than the total
in most Asian countries. It was also more than double the capacity of
the province’s power grid, meaning lots of wasted power.

When this happens, Mining operations, greedy for cheap electricity,
offer the hydro companies small sums of money to set up their operations
right next to the hydro and take the unused energy off the dam's hands.
Everyone wins...


	
+  Miners get cheap energy
+  Hydro companies get money for electricity that would be wasted
+  The environment avoids CO2 emissions


When this happens, the carbon footprint of the mining is essentially 0.

Unfortunately, it's not all sunshine and hydro.

One issue with renewable energy is that it suffers from what is known as
"variability". This means that you only get energy when your energy
source is available.

Solar only produces energy during the day and when the skies are clear.

Wind farms only produce energy when the wind is blowing.

Hydro only produces energy when there is water being held back by the dam.


If the skies are overcast, and the wind isn't blowing, and the dams are
dry from drought, you aren't producing energy.

We can look to Sichuan again to see this problem.

The average power generation capacity during the wet season is three
times that of the dry season. These fluctuations in hydroelectricity
generation need to be balanced out with other types of electricity. 

CWR adds that this is usually coal,” and as a consequence, this renewable
option is not technically 100% green. It should thus be no surprise that
the carbon emission factor of purchased electricity in Sichuan ranges
from 265 to 579 g CO2/kWh, depending on the chosen method.



And it can get worse. What about areas like Missoula County,
Montana, where all of the renewable energy is often used? 

In this case, the mining may often put energy consumption past production,
thereby making someone in the area use to goal or natural gas produced
energy.




The point is: the amount of renewable energy used by Bitcoin is not a
static number. It changes all the time based on the time of year, the
size of the block reward, and multitude of other factors. 

We can make educated guesses, but they are always guesses since much about where
Bitcoins are mined is unknown.

We can make some safe assumptions though:

Bitcoin mining will tend to occur where:

    1. Energy is cheapest
    2. Mining is legal

And due to the variablity of renewables and the inability of many grids
accross the globe to take all of this energy, Bitcoin often acts a sort
of renewable energy sponge. That's because energy that will otherwise be
wasted will be sold at the cheapest rates.

It is, however, important to acknowledge that Bitcoin does produce
greenhouse gases like CO2.

### Bitcoin Uses Energy to Create Something Amazing


So we now understand that Bitcoin does contribute to global CO2
emissions and that is because it will end up using a lot of energy; part
of which will come from fossil fuels.

So what?

Many balk at Bitcoin's large use of energy and end the discussion there,
as if the world gets nothing in return for it.

This is a shallow understanding. In fact, the world is getting something
rather incredible out of this energy.

We are given a decentralized, censorship-resistant, medium of exchange that is unlike anything we have
seen before.

If you want to send someone in Venezuela a billion dollars worth of
value, you can do it for a few dollars in fees, a few minutes of time,
and without anyone permission. 

There is nothing your government or the Venezuelan government can do
to stop you.


How is this possible? This is all possible due to the insanely secure
network Bitcoin works on because of the energy consumption used by
miners. 

The only way to stop a transaction that you did not make is to
control the majority of the hashing power on the network, which means
you would need not only the equipment but also access to an
incomprehensible amount of energy. 

Energy is the real world commodity that makes digital scarcity possible.

So why then should anyone accept that Bitcoin shouldn't exist just
because it uses lots of energy? Do video games not use up lots of
electricity globally? Watching reality television?

How about war? Researchers at Durham University and Lancaster University
actually concluded that the US military allone actually emits more CO2
than most countries do.


In 2017 alone, the US military purchased about 269,230 barrels of oil a
day and emitted more than 25,000 kilotonnes CO2e by burning those fuels.


So who or what then really deserves the energy we produce?

The projects that create and decentralize wealth or the projects that
centralize and destroy it?

### The Realities of Renewables

Unfortunately, we live in a time where renewables just aren't able to
completely replace fossil fuels. Until then, Bitcoin produces a lot of
good and lots of energy consumption allows it to happen. 

Thankfully, Bitcoin eats up what would be a lot of wasted renewable energy, and
helps to create new demand for renewables which allow them to become
profitable faster.

While Bitcoin's carbon footprint is large in absolute terms (the best
estimates seem to suggest its around 26,000 kilotonnes annually), its
carbon footprint relative to its payoff is low. 

That means the US military's fuel burning alone is responsible for nearly as much CO2 as
Bitcoin is.



## Chapter 7: The Future of Bitcoin Mining

So now we know that Bitcoin mining is one of the least carbon-intensive uses for energy on the planet.

But what about the future? How will Bitcoin mining likely change in the months and years to come?

What technological innovations are in the works to combat some of the challenges outlined in chapter 5?
This chapter is all about the future of mining, so read on to get a glimpse of what is coming. 

### Decentralizing the Pools with Stratum V2

In Chapters 5, we talked about some of the challenges to Bitcoin mining going forward. Chief among these is the issue of mining centralization with regard to pools becoming too large.

However, there are projects in play now that seek to solve this particular problem once and for all. 

The first of these was BetterHash, created by ex-Blockstream founder Matt Corallo. Then came SlushPool’s Stratum V2. 

There are a few differences between these two mining pool protocols. But for the purpose of this guide, the idea behind them is the same. Matt also worked with Slush on Stratum V2 to give it all the functionality of BetterHash plus some other great features.

Here is the problem:

Right now, when a particular miner in a pool wins a block for the pool, he doesn’t construct that block himself. He doesn’t choose which transactions get included. He doesn’t even choose which fork his hashing power will go to. 

All of this is decided by the mining pool operator. The actual miner who won the block just gets paid like everyone else does. 

So let’s say a pool controls 45% of all the hashing power. That means one party decides how to construct 45% of all the blocks. And as we mentioned in Chapter 5, this is a centralization risk to the network.

If a government or some other party interested in harming Bitcoin wanted to, they may try to coerce the mining pool operator to act in a way that is bad for Bitcoin. 

With StatrumV2, all of the power to construct blocks and choose forks is given back to the individual miner who found the block.

### All of the Pros. None of the Cons.

You might be wondering, “Doesn’t this just put us back where we started? Didn’t pools come into existence so miners could smooth out their income?”

Yes, and with StratumV2, the miner who finds the block will still have to share the rewards with the pool. The only thing that changes is the power to construct the block is with the miner who found it...not the pool operator. 

In theory, then, a mining pool could have more than 50% hashing power, but they wouldn’t be able to attack Bitcoin with a 51% attack. 

Miners then have the same control as they would if they weren’t part of a pool. But they also get all the benefits of pools in terms of more consistent payouts. 

That means that we can focus on centralization of hashing power by individuals instead of pools. That would change the graph quite a bit:

### Selfishly Giving Up Control

But...why would mining pools implement this? Wouldn’t they want to maintain their control?

Yes, they would. However, the miners want these features and at the end of the day, the miners are the pool’s customers. 

Pools make money off of the fees they earn, and the more hashing power they have, the more money they make.

Stratum was invented by Slushpool, which has already implemented StratumV2 along with Blockstream Pool. On top of the centralization fixes, there are a slew of other features that make miners more money and make pools more efficient. 

Whatever the pool operators lose in power, they more than gain in other features to stratumV2.

### Braiins BOSMiner

Braiins BOSMiner is a mining software written by SlushPool to replace the CGMiner open-source mining software used by almost everyone. 

The issue with CGMiner is that it is poorly maintained. That means that a lot of the pools and miners who use it make their own additions and modifications to it. In most cases, they do not commit these improvements back to the open-source for months or years after they make them.

Slushpool aims to solve this by actively maintaining BOSMiner so that it remains up to date and becomes a standard that everyone can use and rely on.

### Colocation Mining

This one is huge.

As you’ve likely learned in this guide, beginning a profitable mining operation can be extremely difficult and prohibitively expensive. 

The scope and scale of Bitcoin mining today has also resulted in the slow centralization of even individual hashing power into the hands of a few.

But Blockstream has launched what it calls “co-location mining” to combat even this.

The idea is pretty simple:

Blockstream owns and manages its own large-scale industrial mining warehouses across North America (currently in Quebec, Canada and Georgia, USA). Everything from maintenance to cooling to security are handled by Blockstream. 

Blockstream also negotiates well-priced power agreements with local energy companies. 

All of this is possible because Blockstream already mines about 1% of all Bitcoin.

Now, an individual like you can buy a few ASICs and send them to one of Blockstreams co-location mining facilities to mine. 

You have complete control over your hardware from your home computer. You decide which SHA256 coins to mine. You decide which pool to join.

Everything you could do mining from your home, you can do at Blockstream’s co-location facilities, just more cheaply and efficiently. 

#### How is this different from Cloud Mining?

You may be familiar with a thing called “cloud mining”.

If not, here is how it (is supposed to) work:

A company starts up a mining operation. They sell the rights to the hashing power in exchange for money (usually Bitcoin, ironically), and then you are paid out based on the hashing power you bought. 

Here is the issue: almost all of these are scams. In most cases, there are no miners. There is no hashing power. And there is no Bitcoin.

You are just participating in a Ponzi scheme.

If you are ever paid anything, its because someone else paid in after you and they are trying to keep the scam going. 

There have been a few legit Cloud Mining operations, but they aren’t really the same as Blockstreams co-location mining. 

First, you don’t own the mining equipment in a cloud mining operation. Again, all you are really doing is renting the miners. 

Second, you don’t control what coins the miners mine or what pool to direct the hashing power.

Third, you have no transparency on the miners. You can’t monitor anything.

With Blockstream, you are entering into a contract with a well-known and regulated company. You pay Blockstream a fee to use their facility and take advantage of their cheap power.

It is a turnkey mining operation for smaller individuals. 

#### Why is Co-Location Mining Important

The reason you should be excited about this development is that it allows small players to get involved in industrial scale mining. It lowers barriers that have been erected over the past few years

But also, this decentralizes Bitcoin mining to some degree. 

Sure, Blockstream could renege on its contracts and use the miners as it sees fit, but this would be illegal, and you would have some authority to appeal to if they did this. 

As long as Blockstream honors its contract, Bitcoin is decentralized.

It’s not perfect of course. It would be better if it were impossible for Blockstream to violate its contract, but for now, it is an improvement. 
 

## Conclusion

I really hope you got a lot out of this Bitcoin mining guide. 

By now, you should have a pretty clear idea of how difficult it is to run a mining operation today. If you just want Bitcoin, you are almost certainly better off just buying it.

But I’d like to hear from you - what do you think?

Do you still want to mine Bitcoins after learning what it takes to be profitable?

Still curious about Bitcoin’s carbon footprint?

Whatever you're thinking, we want to hear about it. 

Let us know by leaving a comment below. 

