---
layout: home
class: home
permalink: /
title: "Our Goal: Zero&nbsp;Waste <br>and Net Zero Emissions"
subtitle: We help O&G firms monetize their stranded natural gas while meeting their ESG goals.
description: >
  10NetZero offers flexible, no cost solutions to excess natural gas problems. Utilizing our customized plug-n-play products and services, companies can create economic value, reduce Methane, and meet ESG initiatives.
# video:
#   label: Watch the video
#   link: "#"
#   icon: "/assets/img/PlayCircle.svg"
# audio:
#   link: "#"
#   icon: "/assets/img/audio.svg"
hero_background: "/assets/img/bg_hero.png"
section_1:
  title: >
    ## Our company **eliminates** the need to flare or waste valuable resources.
  link: "#"
  image: "/assets/img/section_1.png"
  webp-image: '/assets/img/section_1.webp'

section_2:
  title: '<strong>Wasting</strong> Gas is No Longer Necessary'
  image: '/assets/img/global-flaring.jpg'
  webp-image: '/assets/img/global-flaring.webp'
  # title: >
  #   Natural gas flaring is one of the biggest sources of waste and emissions
  # text: Now, it’s no longer necessary
  # bg: "/assets/img/bg_s2.webp"
  # cards:
  # - value: $3.57 Billion
  #   speed: 357 Bcf/year
  #   label: Flared & Vented gas
  # - value: $1.63 Billion
  #   speed: 163 Bcf/year
  #   label: Permitted operating flares
  # - value: $1.4+ Billion
  #   speed: 145 Bcf/year
  #   label: Medium size permian


section_3:
  title: >
    ## A **Growing** Problem
  text: Fields are getting more gaseous, with increasing pressure to do something about it.
  widgets:
  - title: >
      ### Expected Oil Production, USA
    image: "/assets/img/projected-oil-production.png"
    webp-image: "/assets/img/projected-oil-production.webp"
  - title: >
      ### Expected Natural Gas Production, USA
    image: "/assets/img/projected-gas-production.png"
    webp-image: "/assets/img/projected-gas-production.webp"

section_4:
  title: >
    ## **Reducing** CO2e's
  text: Natural gas has already provided immense savings in GHG emissions, and it will continue to do so as net zero initiatives will take decades. We make natural gas even more environmentally friendly by utilizing otherwise wasted natural gas, converting it to electricity, and reducing flare intensity and methane emissions.
  widgets:
  # - title: >
  #     ### Emissions avoidance Per. 1.7 MW System (Tons CO2 e/ye)
  #   image: "/assets/img/w4_11.png"
  # - title: >
  #     ### Emissions avoidance Per. $1.000 investment (Tons CO2 e/ye)
  #   image: "/assets/img/w4_21.png"

  - name: Reduced Methane
    amount: 98
  - name: Reduced CO2e
    amount: 63
  - name: Reduced VOCs
    amount: 93

partners:
 - "/assets/img/p_logo_1.png"
 - "/assets/img/p_logo_2.png"
 - "/assets/img/p_logo_3.png"
 - "/assets/img/p_logo_4.png"
 - "/assets/img/p_logo_5.png"
 - "/assets/img/p_logo_6.png"
---