---
layout: page
title: About Us
---

## Why Choose Us

+ Our Value proposition is very simple - We offer a No-sunk-cost way to monetize wasted resources and reduce operational emissions

+ 10NetZero customers benefit by being able to economically reach their net zero targets, faster and cheaper, while also increasing cashflow

+ 10NetZero solutions do the job eliminating operational flares and supporting operational emission reductions, while allowing the producer to effectively “sell” their gas, on-site.

+ Our solutions reduce CAPEX risk, provide market optionality to midstream company, Eliminating midstream company interaction and levied transportation & marketing fees

+ When our solutions are applied, it creates more value for their natural gas and eliminate operational flares in the process

## How We do it

{:.label}
Scalable, low-cost, power generation and packaged bitcoin mining equipment for onsite use

![mining equipment](/assets/img/mining-equip.png)

{:.label}
Redirecting wasted natural gas from operational flaring to electrical generators that power onsite-mining datacenters

## Our Business Model

{:.model_grid}
+ Mining bitcoin increases the value of Natural Gas, from $3 to $6-14+ / Mcf

+ 10NetZero is the Lowest $/Tonne*CO2 way to reduce operational GHG emissions

+ 10NetZero mines and liquidates Bitcoin for revenue

<!-- 
## Why We are different

<div class="table-responsive-md">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th scope="col"> </th>
          <th scope="col">Our Solution</th>
          <th scope="col">Status Quo</th>
          <th scope="col">Buying Equipment</th>
          <th scope="col">Pipelines / Gathering</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">Increase Reserves</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
        </tr>
        <tr>
          <th scope="row">New Cash Flow</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
        </tr>
        <tr>
          <th scope="row">Cash Generation</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
        </tr>
        <tr>
          <th scope="row">Modular</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
        </tr>
        <tr>
          <th scope="row">LVG Solution</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
        </tr>
        <tr>
          <th scope="row">Remote Site Solution</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
        </tr>
        <tr>
          <th scope="row">High ROI</th>
          <td class="text-center"><i class="fas fa-check text-success h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
          <td class="text-center"><i class="fas fa-times text-danger h4"></i></td>
        </tr>
      </tbody>
    </table>
  </div> -->